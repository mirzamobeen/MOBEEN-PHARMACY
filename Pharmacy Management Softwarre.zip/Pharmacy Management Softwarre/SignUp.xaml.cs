﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pharmacy_Management_Softwarre
{
    /// <summary>
    /// Interaction logic for SignUp.xaml
    /// </summary>
    public partial class SignUp : Window
    {
        public SignUp()
        {
            InitializeComponent();
        }


        SqlConnection SqlCon = new SqlConnection(@"Data Source=DESKTOP-67I6MB0\SQLEXPRESS;Initial Catalog=""MOBEEN PHARMACY"";Integrated Security=True;");

        DataSet ds = new DataSet();

        public void cleartb()
        {
            tbName.Clear();
            tbLID.Clear();
            tbEmail.Clear();
            tbPhone.Clear();
            tbpassword.Clear();
        }

        public bool validation()
        {
            if (String.IsNullOrEmpty(tbLID.Text) || String.IsNullOrEmpty(tbpassword.Password))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(tbLID.Text) || String.IsNullOrWhiteSpace(tbpassword.Password))
            {
                return false;
            }
            return true;
        }




        // Event for Clear Button
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            cleartb();

        }
        // Event for SignUp Button
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (validation() == true)
                {
                    SqlCommand cmd1 = new SqlCommand("select * from PharmacyOwners where LicenseID ='" + tbLID.Text + "'", SqlCon);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd1);
                    adapter.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("The LicenseID: " + tbLID.Text + " Already exists.", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                        ds.Clear();
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand("insert into PharmacyOwners values (@Name, @LicenseID, @Email,@ContactNumber,@Password)", SqlCon);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Name", tbName.Text);
                        cmd.Parameters.AddWithValue("@LicenseID", tbLID.Text);
                        cmd.Parameters.AddWithValue("@Email", tbEmail.Text);
                        cmd.Parameters.AddWithValue("@ContactNumber", tbPhone.Text);
                        //cmd.Parameters.AddWithValue("@Password", tbpassword.Password);
                        cmd.Parameters.AddWithValue("@Password", SecureData.HashString(tbpassword.Password));


                        SqlCon.Open();
                        cmd.ExecuteNonQuery();
                        SqlCon.Close();

                        MessageBox.Show("Successfully Registerd\nNow you can LogIn", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
                        cleartb();

                        // Open the AccountMainPage or perform other actions
                        MainWindow loginWindow = new MainWindow();
                        loginWindow.Show();
                        this.Close();

                    }
                }
                else
                {
                    MessageBox.Show("Some Fields are Empty.\nPlease fill them", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlCon.Close();
                cleartb();
            }

        }
        // Event for login Button
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

            MainWindow loginWindow = new MainWindow();
            loginWindow.Show();
            this.Close();

        }
    }
}
