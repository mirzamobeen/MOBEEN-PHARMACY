﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace Pharmacy_Management_Softwarre
{
    /// <summary>
    /// Interaction logic for PharmacyDashBoard.xaml
    /// </summary>
    public partial class PharmacyDashBoard : Window
    {
        public PharmacyDashBoard()
        {
            InitializeComponent();
        }
        //Medicine Button Event

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Medicines m = new Medicines();
            m.Show();
            this.Close();
        }
        //Companies Button Event
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Companies c = new Companies();
            c.Show();
            this.Close();
        }
        //Customers Button Event

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            customerinfo CI = new customerinfo();
            CI.Show();
            this.Close();
        }
    
       //Exit Button event 
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            MainWindow loginWindow = new MainWindow();
            loginWindow.Show();
            this.Close();

        }
    }
}
