﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace Pharmacy_Management_Softwarre
{
    /// <summary>
    /// Interaction logic for Companies.xaml
    /// </summary>
    public partial class Companies : Window
    {
        public Companies()
        {
            InitializeComponent();
        }
        public void cleartb()
        {
            
            t_name.Clear();
            t_addr.Clear();
            t_con.Clear();
            
        }

        public bool validation()
        {
            if (String.IsNullOrEmpty(t_name.Text) || String.IsNullOrEmpty(t_addr.Text))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(t_name.Text) || String.IsNullOrWhiteSpace(t_addr.Text))
            {
                return false;
            }
            return true;
        }
        SqlConnection SqlCon = new SqlConnection(@"Data Source=DESKTOP-67I6MB0\SQLEXPRESS;Initial Catalog=""MOBEEN PHARMACY"";Integrated Security=True;");

        DataSet ds = new DataSet();
        private void btn_purchase_click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (validation() == true)
                {
                    SqlCommand cmd1 = new SqlCommand("select * from Companies where CompanyName ='" + t_name.Text + "'", SqlCon);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd1);
                    adapter.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("The Company Name: " + t_name.Text + " Already exists.", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                        ds.Clear();
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand("insert into Companies values (@CompanyType, @CompanyName, @CompanyAddress,@ContactNumber)", SqlCon);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@CompanyType", t_type.Text);
                        cmd.Parameters.AddWithValue("@CompanyName", t_name.Text);
                        cmd.Parameters.AddWithValue("@CompanyAddress", t_addr.Text);
                        cmd.Parameters.AddWithValue("@ContactNumber", t_con.Text);

                        //cmd.Parameters.AddWithValue("@Password", SecureData.HashString(tbPassword.Password));


                        SqlCon.Open();
                        cmd.ExecuteNonQuery();
                        SqlCon.Close();

                        MessageBox.Show("Successfully Registerd\nNow you can LogIn", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
                        cleartb();

                        // Open the AccountMainPage or perform other actions
                        MainWindow loginWindow = new MainWindow();
                        loginWindow.Show();
                        this.Close();

                    }
                }
                else
                {
                    MessageBox.Show("Some Fields are Empty.\nPlease fill them", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("abc");
            }
            finally
            {
                SqlCon.Close();
                cleartb();
            }

        }

  

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            PharmacyDashBoard PDB = new PharmacyDashBoard();
            PDB.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (validation() == true)
                {
                    SqlCommand cmd1 = new SqlCommand("select * from Companies where CompanyName ='" + t_name.Text + "'", SqlCon);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd1);
                    adapter.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("The Name: " + t_name.Text + " Already exists.", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                        ds.Clear();
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand("insert into Companies values (@CompanyType, @CompanyName, @CompanyAddress, @ContactNumber)", SqlCon);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@CompanyType", t_type.Text);
                        cmd.Parameters.AddWithValue("@CompanyName", t_name.Text);
                        cmd.Parameters.AddWithValue("@CompanyAddress",t_addr.Text);
                       cmd.Parameters.AddWithValue("@ContactNumber", t_con.Text);
                       
                        //cmd.Parameters.AddWithValue("@Password", SecureData.HashString(tbPassword.Password));


                        SqlCon.Open();
                        cmd.ExecuteNonQuery();
                        SqlCon.Close();

                        MessageBox.Show("Successfully Registerd\nNow you can LogIn", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
                        cleartb();

                         }
                }
                else
                {
                    MessageBox.Show("Some Fields are Empty.\nPlease fill them", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlCon.Close();
                cleartb();
            }
        }
    }
}
