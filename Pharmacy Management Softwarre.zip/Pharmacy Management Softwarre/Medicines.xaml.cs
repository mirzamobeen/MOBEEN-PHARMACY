﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace Pharmacy_Management_Softwarre
{
    /// <summary>
    /// Interaction logic for Medicines.xaml
    /// </summary>
    public partial class Medicines : Window
    {
        public Medicines()
        {
            InitializeComponent();
        }
        SqlConnection SqlCon = new SqlConnection(@"Data Source=DESKTOP-67I6MB0\SQLEXPRESS;Initial Catalog=""MOBEEN PHARMACY"";Integrated Security=True;");
        public void cleartb()
        {
            tm.Clear();
            tq.Clear();
            tu.Clear();
            tp.Clear();
            cn.Clear();
            tc.Clear();
        }

        public bool validation()
        {
            if (String.IsNullOrEmpty(tp.Text) || String.IsNullOrEmpty(tc.Text))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(tp.Text) || String.IsNullOrWhiteSpace(tc.Text))
            {
                return false;
            }
            return true;
        }
        DataSet ds = new DataSet();

     
        
        
        
        //For grid view
        public void Loadgrid()
        {
            SqlCommand sqlCommand = new SqlCommand("Select * from Medicines", SqlCon);
            DataTable dt = new DataTable();
            try
            {
                SqlCon.Open();
                SqlDataReader sdr = sqlCommand.ExecuteReader();
                dt.Load(sdr);
                SqlCon.Close();
                datagrid.ItemsSource = dt.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlCon.Close();
            }
        }



        //For Add Medicine


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (validation() == true)
                {
                    SqlCommand cmd1 = new SqlCommand("select * from Medicines where MedicineName ='" + tm.Text + "'", SqlCon);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd1);
                    adapter.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("The MedicineName: " + tm.Text + " Already exists.", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                        ds.Clear();
                    }
                    else
                    {var date = date_picker.SelectedDate.Value.Date.ToShortDateString();
                        MessageBox.Show(date);

                        SqlCommand cmd = new SqlCommand("insert into Medicines values (@MedicineType, @MedicineName, @Quantity, @UnitPrice, @SalePrice, @CompanyID, @ExpiryDate)", SqlCon);
                       
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@MedicineType", cn.Text);
                        cmd.Parameters.AddWithValue("@MedicineName", tm.Text);
                        cmd.Parameters.AddWithValue("@Quantity", tq.Text);
                        cmd.Parameters.AddWithValue("@UnitPrice", tu.Text);
                        cmd.Parameters.AddWithValue("@SalePrice", tp.Text);
                        cmd.Parameters.AddWithValue("@CompanyID", tc.Text);
                        cmd.Parameters.AddWithValue("@ExpiryDate", date);
                        //cmd.Parameters.AddWithValue("@Password", SecureData.HashString(tbPassword.Password));


                        SqlCon.Open();
                        cmd.ExecuteNonQuery();
                        SqlCon.Close();

                        MessageBox.Show("Successfully Registerd\nNow you can LogIn", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
                        cleartb();

                        // Open the AccountMainPage or perform other actions
                        MainWindow loginWindow = new MainWindow();
                        loginWindow.Show();
                        this.Close();

                    }
                }
                else
                {
                    MessageBox.Show("Some Fields are Empty.\nPlease fill them", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlCon.Close();
                cleartb();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            SqlCon.Open();
            SqlCommand cmd = new SqlCommand("delete from Medicines where userID= " + cb_search.Text + " ", SqlCon);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record has been deleted.", "Deleted", MessageBoxButton.OK, MessageBoxImage.Information);
                SqlCon.Close();
                cleartb();
                Loadgrid();
                SqlCon.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlCon.Close();
            }
        }

        //For Update Medicine

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            SqlCon.Open();
            string query = "update Medicines set MedicineType = " + "'" + cn.Text + "', MedicineName = '" + tm.Text + "', Quantity = '" + tq.Text + "',UnitPrice = '" + tu.Text + "' ,SalePrice = '" + tp.Text + "' ,CompanyID = '" + tc.Text + "' ,ExpiryDate= '" + date_picker.Text + "'" + "" + "WHERE UserID ='" + cb_search.Text + "'";
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, SqlCon))
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record has been Updated successfully", "Updated", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                SqlCon.Close();
                cleartb();
                Loadgrid();
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            cleartb();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Loadgrid();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            PharmacyDashBoard PDB = new PharmacyDashBoard();
            PDB.Show();
            this.Close();
        }
    }
 }

