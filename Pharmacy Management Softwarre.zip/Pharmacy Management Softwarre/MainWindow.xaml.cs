﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace Pharmacy_Management_Softwarre
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        SqlConnection SqlCon = new SqlConnection(@"Data Source=DESKTOP-67I6MB0\SQLEXPRESS;Initial Catalog=""MOBEEN PHARMACY"";Integrated Security=True;");
        public void cleartb()
        {
            tbLID.Clear();
            tbpassword.Clear();
        }
        public bool validation()
        {
            if (String.IsNullOrEmpty(tbLID.Text) || String.IsNullOrEmpty(tbpassword.Password))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(tbLID.Text) || String.IsNullOrWhiteSpace(tbpassword.Password))
            {
                return false;
            }
            return true;
        }
        //Clear Button Event
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            cleartb();
        }
        //Login Button Event
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            validation();
            try
            {
                if (SqlCon.State == ConnectionState.Closed)
                {
                    SqlCon.Open();
                }

                string query = "SELECT COUNT(1) AS OwnerCount, OwnerID FROM PharmacyOwners WHERE LicenseID = @LicenseID AND Password = @Password GROUP BY OwnerID";

                SqlCommand cmd = new SqlCommand(query, SqlCon);

                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@LicenseID", tbLID.Text);
                cmd.Parameters.AddWithValue("@Password", SecureData.HashString(tbpassword.Password));

                // Using SqlDataReader to get both the count and UserId in a single query
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        // Move to the first row of the result set
                        reader.Read();

                        int count = reader.GetInt32(0);
                        int OwnerId = reader.GetInt32(1);

                        if (count == 1)
                        {
                            // Set the global variable
                            AppContext.SetLoggedInOwnerId(OwnerId);

                            // Open the AccountMainPage or perform other actions
                            PharmacyDashBoard PDB = new PharmacyDashBoard();
                            PDB.Show();
                            this.Close();
                        }
                        
                    }
                    else
                        {
                            MessageBox.Show("Pharmacy License ID or Password incorrect!");
                            cleartb();
                        }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlCon.Close();
            }
        }
        //Sign Up Button Event
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            SignUp signUpPage = new SignUp();
            signUpPage.Show();
            this.Close();
        }
    
        //Exit Button Event
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
        this.Close();
        }
    }
}