﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pharmacy_Management_Softwarre
{
    /// <summary>
    /// Interaction logic for customerinfo.xaml
    /// </summary>
    public partial class customerinfo : Window
    {
        public customerinfo()
        {
            InitializeComponent();

        }
        SqlConnection SqlCon = new SqlConnection(@"Data Source=DESKTOP-67I6MB0\SQLEXPRESS;Initial Catalog=""MOBEEN PHARMACY"";Integrated Security=True;");

        DataSet ds = new DataSet();

        public void cleartb()
        {
            tbName.Clear();
            tbAdr.Clear();
            tbEmail.Clear();
            tbPhone.Clear();
            
        }
        public bool validation()
        {
            if (String.IsNullOrEmpty(tbName.Text) || String.IsNullOrEmpty(tbPhone.Text))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(tbName.Text) || String.IsNullOrWhiteSpace(tbPhone.Text))
            {
                return false;
            }
            return true;
        }


        //Clear Button Event
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            cleartb();
        }
        //Add Button Event
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (validation() == true)
                {
                    SqlCommand cmd1 = new SqlCommand("select * from Customers where CustomerName ='" + tbName.Text + "'", SqlCon);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd1);
                    adapter.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("The Name: " + tbName.Text + " Already exists.", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                        ds.Clear();
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand("insert into Customers values (@Name, @Address, @Email,@ContactNumber)", SqlCon);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Name", tbName.Text);
                        cmd.Parameters.AddWithValue("@Address", tbName.Text);
                        cmd.Parameters.AddWithValue("@Email", tbEmail.Text);
                        cmd.Parameters.AddWithValue("@ContactNumber", tbPhone.Text);
                      //cmd.Parameters.AddWithValue("@Password", SecureData.HashString(tbPassword.Password));


                        SqlCon.Open();
                        cmd.ExecuteNonQuery();
                        SqlCon.Close();

                        MessageBox.Show("Successfully Registerd\nNow you can LogIn", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
                        cleartb();

                        // Open the AccountMainPage or perform other actions
                        PharmacyDashBoard PDB = new PharmacyDashBoard();
                        PDB.Show();
                        this.Close();

                    }
                }
                else
                {
                    MessageBox.Show("Some Fields are Empty.\nPlease fill them", "Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlCon.Close();
                cleartb();
            }
        }
    }
}
