﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pharmacy_Management_Softwarre
{
    internal class AppContext
    {
        public static int LoggedInOwnerId { get; private set; }

        public static void SetLoggedInOwnerId(int OwnerId)
        {
            LoggedInOwnerId = OwnerId;
        }
    }
}
